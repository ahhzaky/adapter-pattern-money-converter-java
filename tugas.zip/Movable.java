public interface Movable {
    double getDollar();

    double getRinggit();

    double getEuro();
}
