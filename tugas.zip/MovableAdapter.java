public interface MovableAdapter {
    double getDollar(int nilai);

    double getRinggit(int nilai);

    double getEuro(int nilai);
}
