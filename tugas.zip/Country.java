public class Country implements Movable {
    @Override
    public double getDollar() {
        return 14319;
    }

    @Override
    public double getRinggit() {
        return 3446;
    }

    @Override
    public double getEuro() {
        return 16507;
    }
}